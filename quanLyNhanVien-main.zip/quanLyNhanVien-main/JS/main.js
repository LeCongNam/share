// lưu dữ liệu nhân viên
var dataNV = [];
var editMode = false;
var valueID = null;


// lấy dữ liệu từ form
function getValueInput(selector) {
    let inputElement = document.getElementById(selector).value;
    return inputElement;
}

// set thuộc tính html bằng 1 thuộc tính hoặc 1 phương thức khác
function setHTML(selector, html) {
    let element = document.getElementById(selector);
    element.innerHTML = html;
}

// 2 hàm để nhận biết đang ở chế độ nào
function enableEditmode() {
    editMode = true;
}

function disableEditmode() {
    editMode = false;
}



// hàm sủa dữ liệu
function editmodehandle() {
    // lấy dữ liệu từ form
    var tenNV = getValueInput("usrname");
    var email = getValueInput("email");
    var tele = getValueInput("tel");
    var addr = getValueInput("addr");
    var birthday = getValueInput("namsinh");

    dataNV[valueID] = {
        tenNV,
        email,
        addr,
        tele,
        birthday,
    }

    renderViewNhanVien()

    // xoá edit mode
    disableEditmode();

    // đổi tên nút
    setHTML("btn_add_update", "Thêm nhân viên<i class='ti-save'></i>");

    // clear form
    clearForm();

    // đếm số lượng nhân viên sau khi thêm
    slNhanVien();
}

// hàm xoá dữ liệu khi cập nhật xong
function clearForm() {
    document.getElementById("usrname").value = "";
    document.getElementById("email").value = "";
    document.getElementById("tel").value = "";
    document.getElementById("addr").value = "";
    document.getElementById("namsinh").value = "";
}


// hàm thêm nhân viên mới hoặc chuyển sang chế độ chỉnh sủa
function addNhanVien() {
    if (editMode) {
        editmodehandle();
    } else {
        // lấy dữ liệu từ form
        var tenNV = getValueInput("usrname");
        var email = getValueInput("email");
        var tele = getValueInput("tel");
        var addr = getValueInput("addr");
        var birthday = getValueInput("namsinh");

        var nhanVien = {
            tenNV: tenNV,
            email: email,
            addr: addr,
            tele: tele,
            birthday: birthday,
        }
        // đẩy dữ liệu vào mảng
        dataNV.push(nhanVien);
        // gọi hàm để render dữ liệu vào bảng
        renderViewNhanVien();

        // đếm số lượng nhân viên sau khi thêm
        slNhanVien();
    }
}


// hàm hiển thị xuất dữ liệu  vào bảng
function renderViewNhanVien() {
    var html = ""
    for (let i = 0; i < dataNV.length; i++) {
        var nhanvien = dataNV[i];
        html += "<tr>";
        html += "<td>" + (i + 1) + "</td>";
        html += "<td class='tennv'>" + nhanvien.tenNV + "</td>";
        html += "<td>" + nhanvien.email + "</td>";
        html += "<td>" + nhanvien.addr + "</td>";
        html += "<td>" + nhanvien.tele + "</td>";
        html += "<td>" + nhanvien.birthday + "</td>";
        html += "<td> <button class='btn btn-warning' onclick='showDataEdit(" + (i) + ")'>Edit <i class='ti-info-alt'></i></button></td>";
        html += "<td> <button class='btn btn-danger' onclick='onDeleteNV(" + (i) + ")'>Delete<i class=\"ti-trash\" ></i></button></td>";
        html += "</tr>";

    }
    setHTML("datalist", html);
}
    

// hàm xoá nhân viên
function onDeleteNV(index) {
    var xacNhan = confirm("Bạn chắc chắn muốn xoá?");
    if (xacNhan == true) {
        deleteNV(index);
        renderViewNhanVien();
        // đếm số lượng nhân viên sau khi xoá
        slNhanVien();
    }
}

// hàm con để sử dụng lại
function deleteNV(index) {
    dataNV.splice(index, 1);
}


// hàm để xuất lại dữ liệu dùng cho việc chỉnh sửa
function showDataEdit(index) {
    valueID = index;
    let nhanvien = dataNV[index];
    document.getElementById("usrname").value = nhanvien.tenNV;
    document.getElementById("email").value = nhanvien.email;
    document.getElementById("tel").value = nhanvien.tele;
    document.getElementById("addr").value = nhanvien.addr;
    document.getElementById("namsinh").value = nhanvien.birthday;
    setHTML("btn_add_update", "CẬP NHẬT <i class='ti-save'></i>");
    enableEditmode();

}